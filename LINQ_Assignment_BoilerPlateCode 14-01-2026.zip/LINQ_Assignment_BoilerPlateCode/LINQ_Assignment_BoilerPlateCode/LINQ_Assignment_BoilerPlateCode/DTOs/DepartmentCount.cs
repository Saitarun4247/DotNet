﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Assignment_BoilerPlateCode.DTOs
{
   public class DepartmentCount
    {
        public string Department { get; set; }
        public int Count { get; set; }
    }
}
